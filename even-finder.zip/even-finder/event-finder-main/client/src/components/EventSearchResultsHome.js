import React from 'react';

const EventsSearchResultsHome = () => {
    return (
        <div></div>
    )
};

export default EventsSearchResultsHome;