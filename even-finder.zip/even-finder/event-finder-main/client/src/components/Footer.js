import React from 'react';

const Footer = () => {
    return (
        <div className='flex justify-center py-10 text-sm text-gray-600'>
            <p>EventFinder 2022</p>
        </div>
    )
};

export default Footer;